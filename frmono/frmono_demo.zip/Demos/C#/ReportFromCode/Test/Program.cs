﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FastReport;
using FastReport.Export.Pdf;

namespace ConsoleApp1
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            foreach (var font in new InstalledFontCollection().Families)
            {
                using (var reportStream = new MemoryStream(Convert.FromBase64String(ReportAsBase64)))
                using (var report = Report.FromStream(reportStream))
                {
                    report.FileName = "Report with Wingdings Font";

                    var textObject = report.AllObjects.OfType<TextObject>().First();
                    textObject.Font = new Font(font, 24); //Set font

                    report.Prepare();

                    using (var export = new PDFExport())
                    {
                        try
                        {
                            export.Export(report, new MemoryStream());
                        }
                        catch (NullReferenceException)
                        {
                            Console.WriteLine(font.Name);
                        }
                    }
                }
            }

            Console.ReadLine();
        }

        private const string ReportAsBase64 = "77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4NCjxSZXBvcnQgU2NyaXB0TGFuZ3VhZ2U9IkNTaGFycCIgUmVwb3J0SW5mby5DcmVhdGVkPSIxMi8xNC8yMDE2IDA5OjAzOjU4IiBSZXBvcnRJbmZvLk1vZGlmaWVkPSIxMi8xNC8yMDE2IDA5OjA0OjUwIiBSZXBvcnRJbmZvLkNyZWF0b3JWZXJzaW9uPSIyMDE3LjEuNi4wIj4NCiAgPERpY3Rpb25hcnkvPg0KICA8UmVwb3J0UGFnZSBOYW1lPSJQYWdlMSI+DQogICAgPFJlcG9ydFRpdGxlQmFuZCBOYW1lPSJSZXBvcnRUaXRsZTEiIFdpZHRoPSI3MTguMiIgSGVpZ2h0PSIzNy44Ii8+DQogICAgPFBhZ2VIZWFkZXJCYW5kIE5hbWU9IlBhZ2VIZWFkZXIxIiBUb3A9IjQxLjgiIFdpZHRoPSI3MTguMiIgSGVpZ2h0PSIyOC4zNSIvPg0KICAgIDxEYXRhQmFuZCBOYW1lPSJEYXRhMSIgVG9wPSI3NC4xNSIgV2lkdGg9IjcxOC4yIiBIZWlnaHQ9Ijc1LjYiPg0KICAgICAgPFRleHRPYmplY3QgTmFtZT0iVGV4dDEiIExlZnQ9IjU2LjciIFRvcD0iMTguOSIgV2lkdGg9Ijk0LjUiIEhlaWdodD0iNDcuMjUiIFRleHQ9IkEiIEZvbnQ9IldpbmdkaW5ncywgMjhwdCIvPg0KICAgIDwvRGF0YUJhbmQ+DQogICAgPFBhZ2VGb290ZXJCYW5kIE5hbWU9IlBhZ2VGb290ZXIxIiBUb3A9IjE1My43NSIgV2lkdGg9IjcxOC4yIiBIZWlnaHQ9IjE4LjkiLz4NCiAgPC9SZXBvcnRQYWdlPg0KPC9SZXBvcnQ+DQo=";
    }
}
